// ---------- المتغيرات والثوابت ----------

const ADMIN_USERNAME="admin";

const ADMIN_PASSWORD="Alpo9991";

const ADMIN_PHONE="201113318419"; 

// لتتبع محاولات الدخول الفاشلة بسبب التسجيل على جهاز آخر

let loginAttempts = {}; 

// ---------- تبديل النماذج (لا تغيير) ----------

function showSignup(){ document.getElementById("loginSection").classList.add("hidden"); document.getElementById("signupSection").classList.remove("hidden"); }

function showLogin(){ document.getElementById("signupSection").classList.add("hidden"); document.getElementById("loginSection").classList.remove("hidden"); }

// ---------- إنشاء حساب (لا تغيير) ----------

function signup(){

  const user=document.getElementById("signupUser").value.trim();

  const pass=document.getElementById("signupPass").value.trim();

  const phone=document.getElementById("signupPhone").value.trim();

  const email=document.getElementById("signupEmail").value.trim();

  if(!user||!pass||!phone||!email) return alert("املأ كل الخانات!");

  if(localStorage.getItem("user_"+user)) return alert("الاسم مستخدم بالفعل!");

  if(!/^\d{11}$/.test(phone)) return alert("رقم الهاتف يجب أن يكون 11 رقم فقط!");

  if(!/@gmail\.com$/.test(email)) return alert("البريد يجب أن يكون gmail.com فقط!");

  localStorage.setItem("user_"+user,JSON.stringify({password:pass,phone:phone,email:email,balance:0,logged:false,cart:[], orders:[]}));

  alert("تم إنشاء الحساب!");

  showLogin();

}

// ---------- تسجيل الدخول (خاصية الدخول مرتين) ----------

function login(){

  const user=document.getElementById("loginUser").value.trim();

  const pass=document.getElementById("loginPass").value.trim();

  

  if(user===ADMIN_USERNAME && pass===ADMIN_PASSWORD){

    localStorage.setItem("loggedUser","admin");

    openAdmin();

    return;

  }

  

  const dataStr=localStorage.getItem("user_"+user);

  if(!dataStr) return alert("المستخدم غير موجود!");

  

  const data=JSON.parse(dataStr);

  

  if(data.password!==pass) return alert("كلمة المرور خاطئة!");

  

  // نظام تجاوز قفل الدخول بجهاز آخر

  if(data.logged) {

    if(loginAttempts[user] && loginAttempts[user] > 0) {

        // المحاولة الثانية: فرض الدخول (Force Login)

        data.logged = false; // يفضل تعيينها false لتجنب المشاكل، وتُعين true بعد التحقق

        alert("تجاوز قفل الدخول! تم فرض تسجيل الدخول لهذا الجهاز.");

        loginAttempts[user] = 0; 

    } else {

        // المحاولة الأولى: تنبيه المستخدم والسماح له بالضغط مرة أخرى

        alert("المستخدم مسجل دخول على جهاز آخر! اضغط 'دخول' مرة أخرى إذا كنت متأكداً من عدم استخدام الحساب في مكان آخر.");

        loginAttempts[user] = 1; 

        return; 

    }

  }

  // إذا تم الدخول بنجاح

  data.logged=true;

  localStorage.setItem("user_"+user,JSON.stringify(data));

  localStorage.setItem("loggedUser",user);

  loginAttempts[user] = 0; 

  openHome();

}

// ---------- فتح الصفحات (مُحدث لعرض الرصيد وسجل المشتريات) ----------

function openHome(){

  document.getElementById("accountPage").style.display="none";

  document.getElementById("adminPage").style.display="none";

  document.getElementById("homePage").style.display="block";

  const u=localStorage.getItem("loggedUser");

  

  // 1. جلب بيانات المستخدم لعرض الرصيد

  const userData = JSON.parse(localStorage.getItem("user_" + u) || '{}');

  const userBalance = userData.balance !== undefined ? userData.balance : 0;

  // 2. تحديث العنوان لعرض الرصيد بوضوح

  document.getElementById("homeTitle").innerHTML=`

    🎮 أهلاً بك يا ${u} في Alpo Tik 🎮

    <br>

    <span style="color:#008000; font-weight:bold; font-size:1.1em;">

        متوفر: ${userBalance} ج.م

    </span>

  `;

  // 3. تحميل الأقسام وسجل الطلبات

  loadSections();

  loadUserOrders(); 

}

function openAdmin(){

  document.getElementById("accountPage").style.display="none";

  document.getElementById("homePage").style.display="none";

  document.getElementById("adminPage").style.display="block";

  loadUsers();

  loadSectionsAdmin();

  loadOrdersAdmin(); 

}

// ---------- نسيان كلمة السر (لا تغيير) ----------

function forgotPassword(){ window.open(`https://wa.me/${ADMIN_PHONE}?text=نسيت كلمة السر`,"_blank"); }

// ---------- الخروج (لا تغيير) ----------

function logout(){

  const user=localStorage.getItem("loggedUser");

  if(user && user!=="admin"){

    const data=JSON.parse(localStorage.getItem("user_"+user));

    if(data) data.logged=false;

    localStorage.setItem("user_"+user,JSON.stringify(data));

  }

  localStorage.removeItem("loggedUser");

  document.getElementById("homePage").style.display="none";

  document.getElementById("adminPage").style.display="none";

  document.getElementById("accountPage").style.display="block";

}

// ---------- لوحة المشرف (لا تغيير) ----------

function gotoAdminIfAdmin(){ if(localStorage.getItem("loggedUser")==="admin") openAdmin(); else alert("هذه الصفحة للمشرف فقط."); }

// ---------- إدارة المستخدمين (لا تغيير) ----------

function loadUsers(){

  const container=document.getElementById("usersList");

  container.innerHTML="";

  let keys=Object.keys(localStorage).filter(k=>k.startsWith("user_"));

  if(keys.length===0){ container.innerHTML="<p>لا يوجد مستخدمين</p>"; return; }

  keys.forEach(k=>{

    const username=k.replace("user_","");

    const u=JSON.parse(localStorage.getItem(k));

    const div=document.createElement("div");

    div.className="userCard";

    div.innerHTML=`<p>👤 <b>${username}</b> | 📞 ${u.phone} | ✉️ ${u.email} | 💰 ${u.balance} جنيه</p>

      <button class="smallBtn" onclick="editUser('${username}')">تعديل</button>

      <button class="smallBtn" onclick="deleteUser('${username}')">حذف</button>

      <button class="smallBtn" onclick="chargeUser('${username}')">خصم/شحن</button>`;

    container.appendChild(div);

  });

}

function editUser(username){

  const key="user_"+username;

  const data=JSON.parse(localStorage.getItem(key));

  const phone=prompt("رقم الهاتف:", data.phone);

  if(phone===null) return;

  if(!/^\d{11}$/.test(phone)) return alert("رقم الهاتف يجب أن يكون 11 رقم فقط!");

  const email=prompt("البريد:", data.email);

  if(email===null) return;

  if(!/@gmail\.com$/.test(email)) return alert("البريد يجب أن يكون gmail.com فقط!");

  const pass=prompt("كلمة المرور (فارغ = لا تغيير):","");

  data.phone=phone.trim();

  data.email=email.trim();

  if(pass.trim()!=="") data.password=pass.trim();

  localStorage.setItem(key,JSON.stringify(data));

  loadUsers();

}

function deleteUser(username){ if(!confirm("حذف "+username+"؟")) return; localStorage.removeItem("user_"+username); loadUsers(); }

function chargeUser(username){

  const key="user_"+username;

  const data=JSON.parse(localStorage.getItem(key));

  const amt=prompt("كم المبلغ؟ (يمكن خصم بالسالب)","");

  if(!amt || isNaN(amt)) return alert("قيمة غير صحيحة");

  const newBalance=Number(data.balance)+Number(amt);

  if(newBalance<0) return alert("الرصيد لا يكفي!");

  data.balance=newBalance;

  localStorage.setItem(key,JSON.stringify(data));

  loadUsers();

  // تحديث الرصيد للمستخدم الحالي

  if(localStorage.getItem("loggedUser") === username) openHome(); 

}

// ----------------------------------------------------

// ---------- الأقسام والسلع (وظائف أساسية) ----------

// ----------------------------------------------------

function saveSections(sections){ localStorage.setItem("sections", JSON.stringify(sections)); }

function getSectionByPath(path){

    let sections = JSON.parse(localStorage.getItem("sections") || "[]");

    let currentSection = { sub: sections }; 

    for (const index of path) {

        if (!currentSection.sub || index >= currentSection.sub.length) return null;

        currentSection = currentSection.sub[index];

    }

    return currentSection;

}

function updateSectionByPath(path, updatedSection){

    let sections = JSON.parse(localStorage.getItem("sections") || "[]");

    

    // حالة القسم الرئيسي (العمق 1)

    if (path.length === 1) { 

        sections[path[0]] = updatedSection; 

        saveSections(sections);

        return true; 

    }

    

    // حالة القسم الفرعي (العمق 2 فما فوق)

    let parentPath = path.slice(0, -1);

    let parentSection = getSectionByPath(parentPath);

    if (parentSection && parentSection.sub) {

        const targetIndex = path[path.length - 1];

        if (targetIndex >= 0 && targetIndex < parentSection.sub.length) {

            parentSection.sub[targetIndex] = updatedSection;

            // يجب تحديث المسار الأب للحفظ

            return updateSectionByPath(parentPath, parentSection);

        }

    }

    return false;

}

// وظائف إضافة وحذف الأقسام

function addSection(){

  const name=document.getElementById("newSectionName").value.trim();

  if(!name) return alert("أدخل اسم القسم!");

  let sections=JSON.parse(localStorage.getItem("sections")||"[]");

  sections.push({name:name, sub:[], products:[]}); 

  saveSections(sections);

  document.getElementById("newSectionName").value="";

  loadSectionsAdmin();

}

function deleteSection(pathStr){

    if(!confirm("حذف القسم ومحتوياته؟")) return;

    const path = pathStr.split(',').map(Number);

    let sections = JSON.parse(localStorage.getItem("sections") || "[]");

    

    if (path.length === 1) { sections.splice(path[0], 1); } 

    else {

        let parentPath = path.slice(0, -1);

        let parentSection = getSectionByPath(parentPath);

        if (parentSection && parentSection.sub) {

            parentSection.sub.splice(path[path.length - 1], 1);

            // يجب تحديث المسار الأب بعد الحذف

            updateSectionByPath(parentPath, parentSection);

        }

    }

    saveSections(sections);

    loadSectionsAdmin();

    loadSections(); 

}

function addSubSection(parentPathStr){

    const name = prompt("أدخل اسم القسم الفرعي الجديد:","");

    if(!name) return;

    

    const parentPath = parentPathStr.split(',').map(Number);

    let parentSection = getSectionByPath(parentPath);

    

    if (parentSection) {

        if (!parentSection.sub) parentSection.sub = [];

        parentSection.sub.push({name:name, sub:[], products:[]});

        updateSectionByPath(parentPath, parentSection);

        loadSectionsAdmin();

    }

}

// وظائف إضافة وحذف وتعديل السلع

function addProduct(parentPathStr){

    const parentPath = parentPathStr.split(',').map(Number);

    let parentSection = getSectionByPath(parentPath);

    if (!parentSection) return alert("خطأ في تحديد القسم.");

    const name = prompt("اسم السلعة/المنتج:","");

    if (!name) return;

    const price = prompt("سعر السلعة (بالجنيه):","0");

    if (isNaN(price) || Number(price) < 0) return alert("أدخل سعراً صحيحاً!");

    

    const image = prompt("رابط الصورة (اختياري):","");

    const requiredInputType = prompt("ماذا تحتاج من المستخدم عند الشراء؟ (اكتب 'ID', 'Link', 'Video', أو اتركها فارغة لعدم طلب شيء):","");

    const newProduct = {

        name: name,

        price: Number(price),

        image: image.trim(),

        input: requiredInputType.trim().toLowerCase() 

    };

    if (!parentSection.products) parentSection.products = [];

    parentSection.products.push(newProduct);

    updateSectionByPath(parentPath, parentSection);

    loadSectionsAdmin();

}

function editProduct(pathStr, productIndex){

    const path = pathStr.split(',').map(Number);

    const section = getSectionByPath(path);

    if (!section || !section.products || !section.products[productIndex]) return alert("خطأ في تحديد السلعة.");

    let p = section.products[productIndex];

    

    const name = prompt("اسم السلعة:", p.name);

    if (!name) return;

    

    const price = prompt("سعر السلعة:", p.price);

    if (isNaN(price) || Number(price) < 0) return alert("أدخل سعراً صحيحاً!");

    

    const image = prompt("رابط الصورة:", p.image);

    const requiredInputType = prompt("مدخل المستخدم المطلوب (ID, Link, Video, أو فارغ):", p.input);

    p.name = name.trim();

    p.price = Number(price);

    p.image = image.trim();

    p.input = requiredInputType.trim().toLowerCase();

    section.products[productIndex] = p;

    updateSectionByPath(path, section);

    loadSectionsAdmin();

    loadSections();

}

function deleteProduct(pathStr, productIndex){

    if(!confirm("حذف السلعة؟")) return;

    const path = pathStr.split(',').map(Number);

    const section = getSectionByPath(path);

    if (section && section.products) {

        section.products.splice(productIndex, 1);

        updateSectionByPath(path, section);

        loadSectionsAdmin();

        loadSections();

    }

}

// ----------------------------------------------------

// ---------- وظيفة عرض الأقسام والسلع للمشرف (لإظهار الهيكل الشجري) ----------

// ----------------------------------------------------

function loadSectionsAdmin(){

  const container = document.getElementById("sectionsList");

  container.innerHTML = "";

  let sections = JSON.parse(localStorage.getItem("sections") || "[]");

  

  // دالة مساعدة لعرض الأقسام بشكل متكرر (Recursion)

  function renderAdminSections(arr, parentPathStr, targetDiv){

    arr.forEach((section, index) => {

      const currentPath = parentPathStr ? `${parentPathStr},${index}` : `${index}`;

      

      const sectionDiv = document.createElement("div");

      // نستخدم التنسيق "section" للأقسام الرئيسية ونضيف تنسيق "subSectionContainer" للأقسام الفرعية لجعلها متداخلة بصرياً

      if (parentPathStr === "") {

        sectionDiv.className = "section"; // الأقسام الرئيسية تستخدم تنسيق القسم العادي

      } else {

        // للأقسام الفرعية، نضع الأزرار والمحتوى في div ثم نضع هذا div داخل subSectionContainer

        sectionDiv.className = "section subSectionContainer";

      }

      let sectionHtml = `

        <p><b>${section.name}</b></p>

        <button class="smallBtn" onclick="addSubSection('${currentPath}')">➕ قسم فرعي</button>

        <button class="smallBtn" onclick="addProduct('${currentPath}')">➕ سلعة</button>

        <button class="smallBtn" onclick="deleteSection('${currentPath}')">❌ حذف القسم</button>

      `;

      

      // عرض السلع داخل هذا القسم

      if(section.products && section.products.length > 0){

          section.products.forEach((p, pIndex) => {

            const inputReq = p.input ? ` (مطلوب: ${p.input.toUpperCase()})` : '';

            const imageHtml = p.image ? `<img src="${p.image}" class="productImg" alt="${p.name}">` : '';

            sectionHtml += `

              <div class="product">

                <div class="productDetails">

                  <div class="productInfo">

                    ${imageHtml} <b>${p.name}</b> - السعر: ${p.price} ج.م ${inputReq}

                  </div>

                  <div class="productAction">

                    <button class="smallBtn" onclick="editProduct('${currentPath}', ${pIndex})">تعديل</button>

                    <button class="smallBtn" onclick="deleteProduct('${currentPath}', ${pIndex})">حذف</button>

                  </div>

                </div>

              </div>

            `;

          });

      }

      sectionDiv.innerHTML = sectionHtml;

      targetDiv.appendChild(sectionDiv);

      

      // إذا كان هناك أقسام فرعية، نكرر الدالة لعمق آخر

      if(section.sub && section.sub.length > 0){

        // نمرر الـ sectionDiv الحالي ليكون هو الحاوية للأقسام الفرعية الجديدة

        renderAdminSections(section.sub, currentPath, sectionDiv);

      }

    });

  }

  // بدأ العرض من الأقسام الرئيسية

  renderAdminSections(sections, "", container);

}

// ----------------------------------------------------

// ---------- وظيفة عرض الأقسام والسلع للمستخدم (لتظهر الأقسام المتداخلة) ----------

// ----------------------------------------------------

function loadSections(){

    const container = document.getElementById("sectionsContainer");

    container.innerHTML = "";

    let sections = JSON.parse(localStorage.getItem("sections") || "[]");

    function renderUserSections(arr, targetDiv, isSub=false){

        arr.forEach(section => {

            const sectionDiv = document.createElement("div");

            // للأقسام الفرعية، نطبق تنسيق subSectionContainer لإظهار التداخل

            sectionDiv.className = "section" + (isSub ? " subSectionContainer" : "");

            

            let sectionHtml = `<h3>${section.name}</h3>`;

            

            if(section.products && section.products.length > 0){

                section.products.forEach((p, pIndex) => {

                    const imageHtml = p.image ? `<img src="${p.image}" class="productImg" alt="${p.name}">` : '';

                    sectionHtml += `

                      <div class="product">

                        <div class="productDetails">

                          <div class="productInfo">

                            ${imageHtml} <b>${p.name}</b> - السعر: ${p.price} ج.م

                          </div>

                          <div class="productAction">

                            <button class="smallBtn" onclick="addToCart('${p.name}', ${p.price}, '${p.input}')">🛒 إضافة</button>

                          </div>

                        </div>

                      </div>

                    `;

                });

            }

            sectionDiv.innerHTML = sectionHtml;

            targetDiv.appendChild(sectionDiv);

            if(section.sub && section.sub.length > 0){

                // نمرر القسم الحالي كـ targetDiv ونحدد isSub بـ true

                renderUserSections(section.sub, sectionDiv, true);

            }

        });

    }

    renderUserSections(sections, container);

}

// ----------------------------------------------------

// ---------- وظائف السلة والمشتريات (لا تغيير) ----------

// ----------------------------------------------------

function addToCart(name, price, inputType){

    const user = localStorage.getItem("loggedUser");

    if (!user || user === "admin") return alert("سجل الدخول كمستخدم للشراء.");

    

    let requiredValue = "";

    if (inputType) {

        let promptText = "";

        switch(inputType) {

            case 'id': promptText = "أدخل ID المستخدم المطلوب شحنه:"; break;

            case 'link': promptText = "أدخل رابط الصفحة/البروفايل:"; break;

            case 'video': promptText = "أدخل رابط الفيديو:"; break;

            default: promptText = `أدخل القيمة المطلوبة (${inputType}):`;

        }

        requiredValue = prompt(promptText);

        if (requiredValue === null || requiredValue.trim() === "") return alert("يجب إدخال القيمة المطلوبة لإتمام الإضافة للسلة.");

    }

    const userKey = "user_" + user;

    const userData = JSON.parse(localStorage.getItem(userKey));

    

    if(!userData.cart) userData.cart = []; // التأكد من وجود مصفوفة السلة

    userData.cart.push({ name: name, price: price, inputType: inputType, inputValue: requiredValue.trim() });

    localStorage.setItem(userKey, JSON.stringify(userData));

    alert("تمت إضافة " + name + " إلى السلة!");

}

function viewCart(){

    const user = localStorage.getItem("loggedUser");

    if (!user || user === "admin") return;

    

    const userData = JSON.parse(localStorage.getItem("user_" + user));

    const cartContent = document.getElementById("cartContent");

    cartContent.innerHTML = "";

    

    let total = 0;

    if (!userData.cart || userData.cart.length === 0) {

        cartContent.innerHTML = "<p>السلة فارغة.</p>";

    } else {

        userData.cart.forEach((item, index) => {

            const inputDisplay = item.inputValue ? `<br>(${item.inputType.toUpperCase()}: ${item.inputValue})` : '';

            cartContent.innerHTML += `<p>

                ${item.name} - ${item.price} ج.م ${inputDisplay}

                <button class="smallBtn" onclick="removeFromCart(${index})">❌</button>

            </p>`;

            total += item.price;

        });

    }

    cartContent.innerHTML += `<hr><h3>المجموع: ${total} جنيه</h3>`;

    

    if (userData.cart && userData.cart.length > 0) {

        // زر إتمام الشراء

        cartContent.innerHTML += `<button onclick="checkout(${total})">💰 إتمام الشراء والخصم من الرصيد</button>`;

    }

    document.getElementById("cartModal").style.display = "block";

}

function removeFromCart(index){

    const user = localStorage.getItem("loggedUser");

    const userKey = "user_" + user;

    const userData = JSON.parse(localStorage.getItem(userKey));

    

    userData.cart.splice(index, 1);

    localStorage.setItem(userKey, JSON.stringify(userData));

    viewCart(); 

}

function checkout(total){

    const user = localStorage.getItem("loggedUser");

    

    if (user === ADMIN_USERNAME || !user) {

        alert("خطأ: لا يمكن للمشرف إتمام الشراء من لوحة المستخدم.");

        return;

    }

    const userKey = "user_" + user;

    let userData = JSON.parse(localStorage.getItem(userKey));

    

    if (!userData.cart || userData.cart.length === 0) {

        alert("لا يوجد سلع في سلة المشتريات.");

        return;

    }

    

    if(userData.balance < total) {

        alert(`رصيدك الحالي ${userData.balance} جنيه، وهو لا يكفي. تحتاج ${total - userData.balance} جنيه إضافي. برجاء شحن الحساب.`);

        return;

    }

    

    // 1. خصم المبلغ من الرصيد فوراً

    userData.balance -= total;

    

    // 2. تجميع تفاصيل الطلب

    const orderDetails = {

        id: Date.now(),

        user: user,

        phone: userData.phone,

        email: userData.email,

        total: total,

        items: [...userData.cart], 

        date: new Date().toLocaleString(),

        status: 'pending' 

    };

    

    // 3. حفظ الطلب في قائمة الطلبات العامة (Orders)

    let orders = JSON.parse(localStorage.getItem('orders') || '[]');

    orders.unshift(orderDetails); 

    localStorage.setItem('orders', JSON.stringify(orders));

    // 4. مسح سلة المشتريات

    userData.cart = [];

    

    // 5. حفظ بيانات المستخدم الجديدة

    localStorage.setItem(userKey, JSON.stringify(userData));

    // 6. عرض التأكيد للمستخدم وإغلاق السلة

    alert(`✅ تم خصم المبلغ بنجاح! الرصيد المتبقي: ${userData.balance} جنيه. سيقوم المشرف بتنفيذ طلبك قريباً.`);

    closeCart();

    // 7. تحديث عرض الرصيد في الصفحة الرئيسية وسجل الطلبات

    openHome();

}

function closeCart(){

    document.getElementById("cartModal").style.display = "none";

}

// ----------------------------------------------------

// ---------- سجل الطلبات (لا تغيير) ----------

// ----------------------------------------------------

function loadUserOrders(){

    const user = localStorage.getItem("loggedUser");

    const container = document.getElementById("userOrdersList");

    container.innerHTML = "";

    

    let allOrders = JSON.parse(localStorage.getItem('orders') || '[]');

    const userOrders = allOrders.filter(order => order.user === user);

    if (userOrders.length === 0) {

        container.innerHTML = "<p>لا توجد لديك طلبات سابقة.</p>";

        return;

    }

    userOrders.forEach((order, index) => {

        const statusClass = order.status === 'completed' ? 'status-completed' : 'status-pending';

        const statusText = order.status === 'completed' ? '✅ تم التنفيذ' : '⏳ قيد الانتظار';

        

        let itemsHtml = order.items.map(item => {

            const inputDisplay = item.inputValue ? `(${item.inputType.toUpperCase()}: ${item.inputValue})` : '';

            return `<li>${item.name} - ${item.price} ج.م ${inputDisplay}</li>`;

        }).join('');

        const orderDiv = document.createElement("div");

        orderDiv.className = "orderCard";

        orderDiv.innerHTML = `

            <p><strong>#${order.id} | التاريخ: ${order.date}</strong></p>

            <p>الإجمالي: <b>${order.total} ج.م</b></p>

            <p>الحالة: <span class="${statusClass}">${statusText}</span></p>

            <p><b>السلع المطلوبة:</b></p>

            <ul style="list-style-type:disc; padding-right:20px;">${itemsHtml}</ul>

        `;

        container.appendChild(orderDiv);

    });

}

function loadOrdersAdmin(){

    const container = document.getElementById("ordersList");

    container.innerHTML = "";

    let orders = JSON.parse(localStorage.getItem('orders') || '[]');

    if (orders.length === 0) {

        container.innerHTML = "<p>لا توجد طلبات مكتملة حالياً.</p>";

        return;

    }

    orders.forEach((order, index) => {

        const statusClass = order.status === 'completed' ? 'status-completed' : 'status-pending';

        const statusText = order.status === 'completed' ? '✅ تم التنفيذ' : '⏳ في الانتظار';

        

        let itemsHtml = order.items.map(item => {

            const inputDisplay = item.inputValue ? `(${item.inputType.toUpperCase()}: ${item.inputValue})` : '';

            return `<li>${item.name} - ${item.price} ج.م ${inputDisplay}</li>`;

        }).join('');

        const completeButton = order.status !== 'completed' ? 

            `<button class="smallBtn" onclick="markOrderComplete(${index})">وضع علامة "تم"</button>` : 

            '';

        

        const msg = generateWhatsAppMessage(order.items, order.user, order.phone, order.email, order.total);

        const whatsappButton = `<button class="smallBtn" style="background:#25D366; color:white;" onclick="sendOrderToAdminViaWhatsApp('${encodeURIComponent(msg)}')">📱 إرسال للواتس</button>`;

        const orderDiv = document.createElement("div");

        orderDiv.className = "orderCard";

        orderDiv.innerHTML = `

            <p><strong>#${order.id} | التاريخ: ${order.date}</strong></p>

            <p>المستخدم: <b>${order.user}</b> | الإجمالي: <b>${order.total} ج.م</b></p>

            <p>الحالة: <span class="${statusClass}">${statusText}</span> ${completeButton} ${whatsappButton}</p>

            <p>الهاتف: ${order.phone} | البريد: ${order.email}</p>

            <p><b>تفاصيل الطلبات:</b></p>

            <ul style="list-style-type:none; padding-right:0;">${itemsHtml}</ul>

            <button class="smallBtn" onclick="deleteOrder(${index})">❌ حذف الطلب</button>

        `;

        container.appendChild(orderDiv);

    });

}

function markOrderComplete(index){

    let orders = JSON.parse(localStorage.getItem('orders') || '[]');

    if (index >= 0 && index < orders.length) {

        orders[index].status = 'completed';

        localStorage.setItem('orders', JSON.stringify(orders));

        loadOrdersAdmin();

        if(localStorage.getItem("loggedUser") !== ADMIN_USERNAME) loadUserOrders();

    }

}

function deleteOrder(index){

    if(!confirm("هل أنت متأكد من حذف هذا الطلب؟")) return;

    let orders = JSON.parse(localStorage.getItem('orders') || '[]');

    if (index >= 0 && index < orders.length) {

        orders.splice(index, 1);

        localStorage.setItem('orders', JSON.stringify(orders));

        loadOrdersAdmin();

    }

}

function generateWhatsAppMessage(cart, user, phone, email, total){

    const cartItemsText = cart.map(item => {

        let itemInfo = `${item.name} - ${item.price} ج.م`;

        if (item.inputValue) {

            itemInfo += `\n ${item.inputType.toUpperCase()} المطلوب: ${item.inputValue}`;

        }

        return itemInfo;

    }).join('\n-----\n');

    return `🔔 طلب جديد (تم الدفع!) 🔔\n\nالمستخدم: ${user}\nالهاتف: ${phone}\nالمجموع الكلي: ${total} جنيه.\n\nتفاصيل الطلبات:\n\n${cartItemsText}`;

}

function sendOrderToAdminViaWhatsApp(encodedMsg){

    window.open(`https://wa.me/${ADMIN_PHONE}?text=${encodedMsg}`, "_blank");

}

// وظيفة التحقق من حالة الدخول عند تحميل الصفحة (لا تغيير)

(function checkLoginStatus(){

    const user = localStorage.getItem("loggedUser");

    if (user === ADMIN_USERNAME) {

        openAdmin();

    } else if (user) {

        const data = JSON.parse(localStorage.getItem("user_" + user));

        if (data && data.logged) {

            openHome();

        } else {

            localStorage.removeItem("loggedUser");

        }

    }

})();

